This Project is Developed by using googlecolab. Some instructions to run the project
1.upload the Resturant_ChatBot file in googlecolab notebook
2.Now upload the dataCorp.csv  and stopwords.csv files in the current notebook
3.Run the All cells 
4.You can use the chat Bot.
